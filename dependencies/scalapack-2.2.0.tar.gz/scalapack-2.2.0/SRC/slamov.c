//
//  slamov.c
//
//  Written by Lee Killough 04/19/2012
//  

#define TYPE  float
#define FUNC  "SLAMOV"
#define LAMOV slamov_
#define LACPY slacpy_
#include "lamov.h"
