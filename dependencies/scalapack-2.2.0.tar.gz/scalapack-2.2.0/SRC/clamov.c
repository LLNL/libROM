//
//  clamov.c
//
//  Written by Lee Killough 04/19/2012
//  

#define TYPE  complex
#define FUNC  "CLAMOV"
#define LAMOV clamov_
#define LACPY clacpy_
#include "lamov.h"
